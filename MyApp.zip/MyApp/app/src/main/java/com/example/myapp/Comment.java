package com.example.myapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Comment extends AppCompatActivity {

    EditText editText;
    Button submitb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);
        submitb = (Button) findViewById(R.id.submit);
        submitb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText = (EditText)findViewById(R.id.comment_edit);
                editText.setHint("Add your comment Here");
                String comment = editText.getText().toString();
                finish();

            }
        });

//        editText = (EditText)findViewById(R.id.comment_edit);
//        editText.setHint("Add your comment Here");
    }

}
